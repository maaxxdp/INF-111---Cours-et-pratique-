package cours02;


public class Application
{
    public static void main(String[] args)
    {
        Application app = new Application();
        app.AfficherIntroduction();
    }

    public String AfficherIntroduction()
    {
        String msg = "Projet Cours 02 - Mode Application";
        System.out.println(msg);
        return msg;
    }
}
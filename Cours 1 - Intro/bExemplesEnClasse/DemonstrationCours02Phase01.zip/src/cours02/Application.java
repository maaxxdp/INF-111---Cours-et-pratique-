package cours02;


public class Application
{
    public static void main(String[] args)
    {
        Application app = new Application();
        app.AfficherIntroduction();
    }

    public void AfficherIntroduction()
    {
        System.out.println("Projet Cours 02 - Mode Application");
    }
}
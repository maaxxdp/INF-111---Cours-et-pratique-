package test;

import org.junit.jupiter.api.Test;

public class ApplicationTest
{

    @Test
    public void test()
    {
        System.out.println("Projet Cours 02 - Mode Test");
    }
}

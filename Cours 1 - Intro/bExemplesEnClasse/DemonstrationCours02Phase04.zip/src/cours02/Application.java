package cours02;


public class Application
{
    public static void main(String[] args)
    {
        Application app = new Application();
        app.AfficherIntroduction();

        Vecteur v1 = new Vecteur(100        , Math.PI/2);
        Vecteur v2 = new Vecteur(100.00001  , Math.PI/2);
        Vecteur v3 = new Vecteur(100.1      , Math.PI/2);

        System.out.print("Les deux vecteurs suivants sont : ");
        if(v1.equals(v2))
            System.out.println("egaux!");
        else
            System.out.println("different!");

        System.out.println("V1 : " + v1);
        System.out.println("V1 : " + v2);



        System.out.print("Les deux vecteurs suivants sont : ");
        if(v1.equals(v3))
            System.out.println("egaux!");
        else
            System.out.println("different!");

        System.out.println("V1 : " + v1);
        System.out.println("V1 : " + v3);
    }

    public String AfficherIntroduction()
    {
        String msg = "Projet Cours 02 - Mode Application";
        System.out.println(msg);
        return msg;
    }
}
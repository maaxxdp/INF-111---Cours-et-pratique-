package cours02;

public class Vecteur
{
    private final double EPSILON = 0.0001;

    private double x;
    private double y;

    private double amplitude;
    private double orientation;

    public Vecteur()
    {
        this.x = 0;
        this.y = 0;

        this.amplitude   = 0;
        this.orientation = 0;
    }

    public Vecteur(double amplitude, double orientation)
    {
        this.amplitude = amplitude;
        this.orientation = orientation;
        this.polaireACartesien();
    }

    private void polaireACartesien()
    {
        this.x = this.amplitude * Math.cos(this.orientation);
        this.y = this.amplitude * Math.sin(this.orientation);
    }

    private void cartesienAPolaire()
    {
        this.amplitude   = Math.sqrt((this.x *this.x) + (this.y * this.y));
        this.orientation = Math.atan2(this.y, this.x);
    }

    public String toString()
    {
        return String.format("%1.2f N @ %1.2f rad {%1.5f, %1.5f}", this.amplitude,
                                                                    this.orientation,
                                                                    this.x,
                                                                    this.y);
    }

    public boolean equals(Object autreVecteur)
    {
        if(this == null)
            return false;

        if(autreVecteur == null)
            return false;

        Vecteur v = ((Vecteur) autreVecteur);
        return (Math.abs(this.x - v.x) <= EPSILON &&
                Math.abs(this.y - v.y) <= EPSILON);

    }


    public void setX(double x)
    {
        this.x = x;
        this.cartesienAPolaire();
    }

    public void setY(double y)
    {
        this.y = y;
        this.cartesienAPolaire();
    }

    public void setAmplitude(double force)
    {
        this.amplitude = force;
        this.polaireACartesien();
    }

    public void setOrientation(double angle)
    {
        this.orientation = angle;
        this.polaireACartesien();
    }



    public double getX()
    {
        return this.x;
    }

    public double getY()
    {
        return this.y;
    }

    public double getAmplitude()
    {
        return this.amplitude;
    }

    public double getOrientation()
    {
        return this.orientation;
    }
}

package test;


import java.lang.Math;
import cours02.Vecteur;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ApplicationTest
{

    @Test
    public void test()
    {
        System.out.println("Projet Cours 02 - Mode Test");
    }

    @Test
    public void TestConstructeurParDefaut()
    {
        Vecteur unVecteur = new Vecteur();

        assertEquals(0, unVecteur.getX());
        assertEquals(0, unVecteur.getY());
        assertEquals(0, unVecteur.getAmplitude());
        assertEquals(0, unVecteur.getOrientation());
    }

    @Test
    public void TestConstructeurParInitialisation()
    {
        Vecteur unVecteur = new Vecteur(100, Math.PI/6);

        assertEquals(100        , unVecteur.getAmplitude());
        assertEquals(Math.PI/6  , unVecteur.getOrientation(), 0.0001);
        assertEquals(86.6       , unVecteur.getX()          , 0.1);
        assertEquals(50.0       , unVecteur.getY()          , 0.1);
    }

    @Test
    public void TestMutateurs()
    {
        Vecteur unVecteur = new Vecteur(70.71, Math.PI/4);
        assertEquals(70.71      , unVecteur.getAmplitude());
        assertEquals(Math.PI/4  , unVecteur.getOrientation(), 0.0001);
        assertEquals(50.0       , unVecteur.getX()          , 0.1);
        assertEquals(50.0       , unVecteur.getY()          , 0.1);


        unVecteur.setX(10);
        assertEquals(10.0       , unVecteur.getX()          , 0.1);
        assertEquals(50.0       , unVecteur.getY()          , 0.1);
        assertEquals(50.99      , unVecteur.getAmplitude()  , 0.1);
        assertEquals(1.37       , unVecteur.getOrientation(), 0.01);


        unVecteur.setY(0);
        assertEquals(10.0       , unVecteur.getX()          , 0.1);
        assertEquals( 0.0       , unVecteur.getY()          , 0.1);
        assertEquals(10.0       , unVecteur.getAmplitude()  , 0.1);
        assertEquals(0          , unVecteur.getOrientation(), 0.01);


        unVecteur.setOrientation(Math.PI / 2);
        assertEquals(10         , unVecteur.getAmplitude()  , 0.1);
        assertEquals(1.57       , unVecteur.getOrientation(), 0.01);
        assertEquals(0          , unVecteur.getX()          , 0.1);
        assertEquals(10         , unVecteur.getY()          , 0.1);

        unVecteur.setAmplitude(50);
        assertEquals(50         , unVecteur.getAmplitude()  , 0.1);
        assertEquals(1.57       , unVecteur.getOrientation(), 0.01);
        assertEquals(0          , unVecteur.getX()          , 0.1);
        assertEquals(50         , unVecteur.getY()          , 0.1);
    }
}

package cours02;

public class Vecteur
{
    private double x;
    private double y;

    private double amplitude;
    private double orientation;

    public Vecteur()
    {
        this.x = 0;
        this.y = 0;

        this.amplitude   = 0;
        this.orientation = 0;
    }

    public Vecteur(double amplitude, double orientation)
    {
        this.amplitude = amplitude;
        this.orientation = orientation;
    }

    public double getX()
    {
        return this.x;
    }

    public double getY()
    {
        return this.y;
    }

    public double getAmplitude()
    {
        return this.amplitude;
    }

    public double getOrientation()
    {
        return this.orientation;
    }
}

package test;


import java.lang.Math;
import cours02.Vecteur;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ApplicationTest
{

    @Test
    public void test()
    {
        System.out.println("Projet Cours 02 - Mode Test");
    }

    @Test
    public void ConstructeurParDefaut()
    {
        Vecteur unVecteur = new Vecteur();

        assertEquals(0, unVecteur.getX());
        assertEquals(0, unVecteur.getY());
        assertEquals(0, unVecteur.getAmplitude());
        assertEquals(0, unVecteur.getOrientation());
    }

    @Test
    public void ConstructeurParInitialisation()
    {
        Vecteur unVecteur = new Vecteur(100, Math.PI/6);

        assertEquals(0, unVecteur.getX());
        assertEquals(0, unVecteur.getY());
        assertEquals(100, unVecteur.getAmplitude());
        assertEquals(Math.PI/6, unVecteur.getOrientation(), 0.0001);
    }
}
